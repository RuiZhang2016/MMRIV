import torch
import torch.autograd as ag
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
from scenarios.abstract_scenario import AbstractScenario
import time
import matplotlib.pyplot as plt

def Kernel(name):
    def poly(x,c,d):
        return (x @ x.T+c*c)**d
    def rbf(x,a):
        x = x*a
        x2 = torch.sum(x**2,dim=1,keepdim=True)
        sqdist = x2+x2.T-2*x@x.T
        out = torch.exp(-sqdist)
        return out

    def laplace(x,a):
        return 0

    assert isinstance(name,str), 'name should be a string'
    kernel_dict = {'rbf':rbf,'poly':poly}
    return kernel_dict[name]

class Net(nn.Module):

    def __init__(self,input_size):
        super(Net, self).__init__()
        # an affine operation: y = Wx + b
        self.fc1 = nn.Linear(input_size, 128)  # 6*6 from image dimension
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 32)
        self.fc4 = nn.Linear(32, 1)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        x = self.fc4(x)
        return x

def example(scenario_name,seed=527):

    # torch.manual_seed(seed)
    # np.random.seed(seed)

    # load data
    scenario_path = "../data/zoo/" + scenario_name + ".npz"
    scenario = AbstractScenario(filename=scenario_path)
    scenario.to_2d()
    scenario.info()

    train = scenario.get_dataset("train")
    dev = scenario.get_dataset("dev")
    test = scenario.get_dataset("test")

    x,z,y = torch.from_numpy(train.x).float(),torch.from_numpy(train.z).float(),torch.from_numpy(train.y).float()
    # x = np.random.randn(2000,1)
    # y = np.exp(-x*x/2)
    # x, y = torch.from_numpy(x).float(),torch.from_numpy(y).float()
    # test_x = np.random.randn(2000, 1)
    # test_y = np.exp(-test_x * test_x / 2)

    n_data = x.shape[0]

    # Neural Network
    net = Net(x.shape[1])
    n_epochs = 200
    batch_size = 200

    # kernel params
    kernel = Kernel('rbf')
    # a = ag.Variable(torch.ones((1,z.shape[1])), requires_grad=True)
    # g = 1
    # c = 0.1# ag.Variable(torch.tensor(0.1), requires_grad=True)

    # create your optimizer
    optimizer = optim.LBFGS(list(net.parameters()),lr=0.001)
    # es = EarlyStopping(patience=5)

    for epoch in range(n_epochs):
        permutation = torch.randperm(n_data)

        for i in range(0, n_data, batch_size):
            optimizer.zero_grad()  # zero the gradient buffers
            indices = permutation[i:i + batch_size]
            batch_x, batch_z, batch_y = x[indices], z[indices], y[indices]
            # in your training loop:

            def my_loss(output, target, iv):
                d = output-target
                # W = kernel(iv, a)
                #ind = np.diag_indices(W.shape[0])
                #W[ind[0], ind[1]] = torch.zeros(W.shape[0])
                #loss = d.T@kernel(iv,g,c,2)@d
                loss =  d.T @d/d.shape[0]
                return loss[0,0]

            def closure():
                # net.zero_grad()
                optimizer.zero_grad()
                pred_y = net(batch_x)
                loss = my_loss(pred_y, batch_y, None)
                loss.backward()
                return loss

            # loss = my_loss(pred_y, batch_y, batch_z)

            # loss.backward()
            optimizer.step(closure)    # Does the update

        # oos_perf = data_generator.monte_carlo_error(
        #     lambda x, z, t: net(torch.from_numpy(np.hstack((x, t))).float()).detach().numpy(), datafunction,
        #     has_latent=images, debug=False)
        # train_pred_y = net(torch.from_numpy(np.hstack((x, t))).float()).detach().numpy()
        # train_loss = ((train_pred_y-y.numpy())**2).mean()
        # loss_list += [[epoch, train_loss,oos_perf]]

        if epoch%2==0 and epoch>0:
            print('epoch: {}/{} ---- loss: {}'.format(epoch,n_epochs,closure()))
            test_err = ((net(torch.from_numpy(test.x).float()).detach().numpy()-test.y)**2).mean()
            print('test {}'.format(test_err))

if __name__ == '__main__':
    example('Linear')
    # loss_list = np.load('../tmp/ours_res.npy',allow_pickle=True)
    # plt.plot(loss_list[:,0],loss_list[:,1],label='train')
    # plt.plot(loss_list[:,0],loss_list[:,2],label='test')
    # plt.legend()
    # plt.show()